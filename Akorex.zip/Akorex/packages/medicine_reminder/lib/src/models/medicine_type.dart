enum MedicineType {
  Skin,
  Hair,
  Nails,
  Weight,
  None,
}
